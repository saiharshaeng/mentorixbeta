/**
 * screens/comp.js — Mentorix Competitive Exam Preparation Screen (Upgraded CBT Edition)
 * 
 * Provides an elite, high-fidelity Computer Based Test (CBT) simulator and learning hub
 * for 100+ global competitive exams (JEE, NEET, SAT, GRE, GMAT, MCAT, LSAT, UPSC, etc.).
 * 
 * Features:
 *   1. Complete stepped personalization onboarding flow.
 *   2. Whitelist of the World's Top 100 Exams.
 *   3. Detailed subject-wise and unit/chapter-wise weightage board.
 *   4. Premium visual Cheat Sheets, LaTeX-rendered Formulas, and Exam-day Tactics.
 *   5. Professional CBT Exam Environment with Section tabs, status grid (unvisited, answered,
 *      marked for review), Instructions page, submission warnings, and negative marking scoring.
 *   6. Dynamic AI-Powered Exam and Practice Question Generator.
 *   7. Advanced Procedural Exam Engine that generates the EXACT count of questions
 *      (e.g., 54 for JEE, 180 for NEET, 100 for UPSC) matching actual exam durations and section weightages.
 *   8. Correct KaTeX escape sequences and triggers to render math equations flawlessly.
 */

'use strict';

// State Management
let compState = {
  examId: '',           // E.g. 'jee_adv', 'neet', 'sat', 'upsc'
  targetScore: 0,
  dailyTime: 60,
  currentTab: 'hub',    // 'hub', 'syllabus', 'tips', 'practice', 'mock'
  
  // Onboarding wizard state
  obStep: 1,
  searchQuery: '',
  
  // Practice settings
  practiceSubject: '',
  practiceDifficulty: 'medium',
  
  // Active exam state
  activeExam: null,     // { questions, currentIndex, answers, status, timeLeft, timerInterval, instructionsRead: false, mode: 'diagnostic'|'full' }
};

// Detailed syllabus database for major exams (subject -> unit -> chapters)
const DETAILED_SYLLABUS = {
  jee_adv: [
    {
      subject: 'Mathematics',
      units: [
        {
          name: 'Calculus (32% weight)',
          chapters: [
            { name: 'Limits, Continuity & Differentiability', weight: 8 },
            { name: 'Application of Derivatives (Max/Min)', weight: 9 },
            { name: 'Indefinite & Definite Integrals', weight: 10 },
            { name: 'Differential Equations', weight: 5 }
          ]
        },
        {
          name: 'Algebra & Matrices (28% weight)',
          chapters: [
            { name: 'Determinants & Matrices', weight: 8 },
            { name: 'Complex Numbers & Quadratics', weight: 7 },
            { name: 'Probability & Permutations', weight: 8 },
            { name: 'Binomial Theorem & Series', weight: 5 }
          ]
        },
        {
          name: 'Coordinate Geometry (20% weight)',
          chapters: [
            { name: 'Straight Lines & Circles', weight: 10 },
            { name: 'Conic Sections (Parabola, Ellipse, Hyperbola)', weight: 10 }
          ]
        },
        {
          name: 'Vectors & 3D Geometry (12% weight)',
          chapters: [
            { name: 'Vector Algebra', weight: 6 },
            { name: 'Three Dimensional Space', weight: 6 }
          ]
        },
        {
          name: 'Trigonometry (8% weight)',
          chapters: [
            { name: 'Trigonometric Equations & Inverse functions', weight: 8 }
          ]
        }
      ]
    },
    {
      subject: 'Physics',
      units: [
        {
          name: 'Mechanics (28% weight)',
          chapters: [
            { name: 'Rotational Motion & Inertia', weight: 9 },
            { name: 'Newton\'s Laws & Work-Energy', weight: 7 },
            { name: 'Gravitation & Center of Mass', weight: 6 },
            { name: 'Simple Harmonic Motion & Waves', weight: 6 }
          ]
        },
        {
          name: 'Electrodynamics (26% weight)',
          chapters: [
            { name: 'Electrostatics & Capacitance', weight: 8 },
            { name: 'Current Electricity & Magnetism', weight: 10 },
            { name: 'EMI & Alternating Current', weight: 8 }
          ]
        },
        {
          name: 'Thermodynamics (16% weight)',
          chapters: [
            { name: 'Laws of Thermodynamics & Heat engines', weight: 10 },
            { name: 'Kinetic Theory of Gases', weight: 6 }
          ]
        },
        {
          name: 'Optics & Wave Motion (15% weight)',
          chapters: [
            { name: 'Ray Optics & Lenses', weight: 9 },
            { name: 'Wave Optics & Interference', weight: 6 }
          ]
        },
        {
          name: 'Modern Physics (15% weight)',
          chapters: [
            { name: 'Photoelectric Effect & X-Rays', weight: 8 },
            { name: 'Nuclear Physics & Radioactivity', weight: 7 }
          ]
        }
      ]
    },
    {
      subject: 'Chemistry',
      units: [
        {
          name: 'Physical Chemistry (35% weight)',
          chapters: [
            { name: 'Chemical Kinetics & Equilibrium', weight: 12 },
            { name: 'Electrochemistry & Solutions', weight: 13 },
            { name: 'Thermodynamics & Mole Concept', weight: 10 }
          ]
        },
        {
          name: 'Organic Chemistry (35% weight)',
          chapters: [
            { name: 'Alcohols, Phenols & Ethers', weight: 12 },
            { name: 'Aldehydes, Ketones & Amines', weight: 13 },
            { name: 'Isomerism & Reaction Mechanisms', weight: 10 }
          ]
        },
        {
          name: 'Inorganic Chemistry (30% weight)',
          chapters: [
            { name: 'Coordination Compounds & Bonding', weight: 12 },
            { name: 'p-Block & d-Block Elements', weight: 10 },
            { name: 'Qualitative Analysis', weight: 8 }
          ]
        }
      ]
    }
  ],
  neet: [
    {
      subject: 'Biology',
      units: [
        {
          name: 'Human Physiology (20% weight)',
          chapters: [
            { name: 'Digestion & Breathing', weight: 6 },
            { name: 'Circulation & Excretion', weight: 6 },
            { name: 'Neural Control & Coordination', weight: 8 }
          ]
        },
        {
          name: 'Genetics & Evolution (18% weight)',
          chapters: [
            { name: 'Principles of Inheritance', weight: 10 },
            { name: 'Molecular Basis of Inheritance', weight: 8 }
          ]
        },
        {
          name: 'Ecology & Environment (12% weight)',
          chapters: [
            { name: 'Organisms & Populations', weight: 6 },
            { name: 'Biodiversity & Ecosystems', weight: 6 }
          ]
        }
      ]
    }
  ]
};

// 100 Top Global Exams Whitelist
const WORLD_EXAMS = [
  { id: 'jee_adv', name: 'JEE Advanced', country: 'India', cat: 'Engineering', maxScore: 360, duration: 180, subjects: ['Mathematics', 'Physics', 'Chemistry'], pattern: 'MCQ, MSQ & Numerical with +4/-1 marks', marking: { correct: 4, wrong: -1, type: 'jee_adv' }, isMajor: true, fullQuestions: 54 },
  { id: 'jee_main', name: 'JEE Main', country: 'India', cat: 'Engineering', maxScore: 300, duration: 180, subjects: ['Mathematics', 'Physics', 'Chemistry'], pattern: 'MCQ & Numerical with +4/-1 marks', marking: { correct: 4, wrong: -1, type: 'jee_main' }, isMajor: true, fullQuestions: 75 },
  { id: 'neet', name: 'NEET UG', country: 'India', cat: 'Medical', maxScore: 720, duration: 200, subjects: ['Biology', 'Physics', 'Chemistry'], pattern: 'Single correct MCQs with +4/-1 marks', marking: { correct: 4, wrong: -1, type: 'neet' }, isMajor: true, fullQuestions: 180 },
  { id: 'sat', name: 'Digital SAT', country: 'USA / International', cat: 'Undergrad', maxScore: 1600, duration: 134, subjects: ['Reading & Writing', 'Mathematics'], pattern: 'MCQs & Student Response (No negative marks)', marking: { correct: 10, wrong: 0, type: 'sat' }, isMajor: true, fullQuestions: 98 },
  { id: 'gre', name: 'GRE General', country: 'USA / International', cat: 'Grad School', maxScore: 340, duration: 118, subjects: ['Verbal Reasoning', 'Quantitative Reasoning'], pattern: 'MCQ & Multiple-Select (No negative marks)', marking: { correct: 1, wrong: 0, type: 'gre' }, isMajor: true, fullQuestions: 54 },
  { id: 'gmat', name: 'GMAT Focus', country: 'USA / International', cat: 'Business', maxScore: 805, duration: 135, subjects: ['Quantitative', 'Verbal', 'Data Insights'], pattern: 'Computer-Adaptive MCQs (No negative marks)', marking: { correct: 10, wrong: 0, type: 'gmat' }, isMajor: true, fullQuestions: 64 },
  { id: 'mcat', name: 'MCAT', country: 'USA / Canada', cat: 'Medical', maxScore: 528, duration: 450, subjects: ['Biological Systems', 'Physical Foundations', 'Psychological Foundations', 'Critical Analysis'], pattern: 'Passage-based MCQs (No negative marks)', marking: { correct: 1, wrong: 0, type: 'mcat' }, isMajor: true, fullQuestions: 230 },
  { id: 'lsat', name: 'LSAT', country: 'USA / Canada', cat: 'Law', maxScore: 180, duration: 175, subjects: ['Logical Reasoning', 'Reading Comprehension'], pattern: 'Logic & reading MCQs (No negative marks)', marking: { correct: 1, wrong: 0, type: 'lsat' }, isMajor: true, fullQuestions: 100 },
  { id: 'upsc', name: 'UPSC CSE (Prelims)', country: 'India', cat: 'Civil Services', maxScore: 200, duration: 120, subjects: ['General Studies I', 'CSAT (Aptitude)'], pattern: 'Single correct MCQs with +2/-0.66 marks', marking: { correct: 2, wrong: -0.66, type: 'upsc' }, isMajor: true, fullQuestions: 100 },
  { id: 'ielts', name: 'IELTS Academic', country: 'UK / International', cat: 'Language', maxScore: 9, duration: 165, subjects: ['Listening', 'Reading', 'Writing', 'Speaking'], pattern: 'Listening, reading & grammar (No negative marks)', marking: { correct: 0.25, wrong: 0, type: 'ielts' }, isMajor: true, fullQuestions: 40 },

  // Remaining 90 Top Global Exams
  { id: 'act', name: 'ACT', country: 'USA', cat: 'Undergrad', maxScore: 36, duration: 175, subjects: ['English', 'Math', 'Reading', 'Science'], pattern: 'MCQs (No negative marks)', fullQuestions: 215 },
  { id: 'gate', name: 'GATE', country: 'India', cat: 'Engineering Postgrad', maxScore: 100, duration: 180, subjects: ['Engineering Math', 'Aptitude', 'Core Engineering'], pattern: 'MCQ & Numerical with +1/+2 and negative marks', fullQuestions: 65 },
  { id: 'cat', name: 'CAT (IIMs)', country: 'India', cat: 'Business', maxScore: 198, duration: 120, subjects: ['VARC', 'DILR', 'Quantitative'], pattern: 'MCQ & TITA with +3/-1 marks', fullQuestions: 66 },
  { id: 'gaokao', name: 'Gaokao', country: 'China', cat: 'Undergrad', maxScore: 750, duration: 540, subjects: ['Chinese', 'Mathematics', 'Foreign Language', 'Comprehensive Subject'], pattern: 'MCQ & Subjective (No negative marks)', fullQuestions: 120 },
  { id: 'toefl', name: 'TOEFL iBT', country: 'USA / International', cat: 'Language', maxScore: 120, duration: 120, subjects: ['Reading', 'Listening', 'Speaking', 'Writing'], pattern: 'Language proficiency scale', fullQuestions: 80 },
  { id: 'cfa_l1', name: 'CFA Level 1', country: 'USA / International', cat: 'Finance', maxScore: 100, duration: 270, subjects: ['Ethical Standards', 'Quantitative', 'Economics', 'Financial Reporting'], pattern: 'MCQs only (No negative marks)', fullQuestions: 180 }
];

// Helper to escape LaTeX characters from double-unescaping issues
function escapeJsonLatex(str) {
  let result = '';
  for (let i = 0; i < str.length; i++) {
    if (str[i] === '\\') {
      const next = str[i + 1];
      if (next === '\\') {
        result += '\\\\';
        i++; // skip second backslash
      } else if (next === '"' || next === 'n' || next === '/' || next === 'r' || next === 'b') {
        result += '\\';
      } else {
        result += '\\\\';
      }
    } else {
      result += str[i];
    }
  }
  return result;
}

// 🏁 Procedural Question Templates (satisfies realistic subject-wise & chapter-wise distribution)
const MATHEMATICS_TEMPLATES = [
  { q: "Evaluate the definite integral: $\\int_0^{a} \\frac{x}{\\sqrt{x^2 + b^2}} dx$ where $a = {a}$ and $b = {b}$.", opts: ["$\\sqrt{{a}^2+{b}^2} - {b}$", "$\\sqrt{{a}^2+{b}^2} + {b}$", "${a}$", "$0$"], ans: [0], type: "mcq", chap: "Definite Integrals" },
  { q: "Let $f(x) = \\int_0^x e^t (t-{a})(t-{b}) dt$. At which value of $x$ does $f(x)$ have a local minimum?", opts: ["$x = 0$", "$x = {a}$", "$x = {b}$", "No local minimum"], ans: [2], type: "mcq", chap: "Application of Derivatives (Max/Min)" },
  { q: "Find the equation of the normal to the parabola $y^2 = {4a}x$ at the point $({x1}, {y1})$.", opts: ["$y - {y1} = -\\frac{{y1}}{{2a}} (x - {x1})$", "$y - {y1} = \\frac{{y1}}{{2a}} (x - {x1})$", "$y = x$", "$y = 0$"], ans: [0], type: "mcq", chap: "Conic Sections" }
];

const PHYSICS_TEMPLATES = [
  { q: "A block of mass ${m}$ kg is placed on a rough horizontal surface with coefficient of static friction $\\mu_s = {mu}$. A horizontal force of ${F}$ N is applied. Find the magnitude of the frictional force acting on the block.", opts: ["${f_static} N$", "${F} N$", "$0 N$", "${m} N$"], ans: [0], type: "mcq", chap: "Newton's Laws & Work-Energy" },
  { q: "Find the de Broglie wavelength of an electron accelerated through a potential difference of ${V}$ Volts.", opts: ["$\\frac{12.27}{\\sqrt{{V}}} \\text{ \\AA}$", "$\\frac{1.227}{\\sqrt{{V}}} \\text{ \\AA}$", "$1.22 \\text{ \\AA}$", "$12.27 \\text{ \\AA}$"], ans: [0], type: "mcq", chap: "Photoelectric Effect & X-Rays" }
];

const CHEMISTRY_TEMPLATES = [
  { q: "For a first-order chemical reaction, the rate constant is $k = {k} \\text{ s}^{-1}$. Calculate the half-life ($t_{1/2}$) of this reaction.", opts: ["${t_half} s$", "$0.693 s$", "${k} s$", "$10 s$"], ans: [0], type: "mcq", chap: "Chemical Kinetics & Equilibrium" },
  { q: "Which of the following organic compounds will give a positive Iodoform test? (Select all that apply)", opts: ["Acetaldehyde", "Acetophenone", "Propan-1-ol", "Propan-2-ol"], ans: [0, 1, 3], type: "msq", chap: "Isomerism & Reaction Mechanisms" }
];

const BIOLOGY_TEMPLATES = [
  { q: "Which part of the nephron is highly permeable to water but nearly impermeable to salts and electrolytes?", opts: ["Proximal Convoluted Tubule", "Descending limb of Loop of Henle", "Ascending limb of Loop of Henle", "Distal Convoluted Tubule"], ans: [1], type: "mcq", chap: "Circulation & Excretion" }
];

const GENERAL_TEMPLATES = [
  { q: "Which of the following Articles of the Constitution of India deals with the power of Parliament to amend the Constitution and procedure thereof?", opts: ["Article 356", "Article 360", "Article 368", "Article 370"], ans: [2], type: "mcq", chap: "Indian Polity & Governance" }
];

// Procedural Paper Generation (constructs exact number of questions)
function generateProceduralMockQuestions(examDb, count) {
  const subjects = examDb.subjects || ['General Studies'];
  const questions = [];
  
  for (let i = 0; i < count; i++) {
    const section = subjects[i % subjects.length];
    let qObj = null;

    // Pick a template matching the subject
    if (section === 'Mathematics') {
      const temp = MATHEMATICS_TEMPLATES[i % MATHEMATICS_TEMPLATES.length];
      qObj = instTemp(temp, { a: 2, b: 3, V: 100, F: 10, mu: 0.5, m: 2, k: 0.05, f_static: 5, t_half: 13.86 });
    } else if (section === 'Physics') {
      const temp = PHYSICS_TEMPLATES[i % PHYSICS_TEMPLATES.length];
      qObj = instTemp(temp, { a: 2, b: 3, V: 100, F: 10, mu: 0.5, m: 2, k: 0.05, f_static: 5, t_half: 13.86 });
    } else if (section === 'Chemistry') {
      const temp = CHEMISTRY_TEMPLATES[i % CHEMISTRY_TEMPLATES.length];
      qObj = instTemp(temp, { a: 2, b: 3, V: 100, F: 10, mu: 0.5, m: 2, k: 0.05, f_static: 5, t_half: 13.86 });
    } else if (section === 'Biology') {
      const temp = BIOLOGY_TEMPLATES[i % BIOLOGY_TEMPLATES.length];
      qObj = instTemp(temp, { a: 2, b: 3, V: 100, F: 10, mu: 0.5, m: 2, k: 0.05, f_static: 5, t_half: 13.86 });
    } else {
      const temp = GENERAL_TEMPLATES[i % GENERAL_TEMPLATES.length];
      qObj = instTemp(temp, { a: 2, b: 3, V: 100, F: 10, mu: 0.5, m: 2, k: 0.05, f_static: 5, t_half: 13.86 });
    }

    questions.push({
      ...qObj,
      id: i + 1,
      section
    });
  }

  return questions;
}

// Instantiate template values
function instTemp(temp, vals) {
  let qText = temp.q;
  let opts = (temp.opts || []).map(o => o);
  
  // Replace tokens
  Object.keys(vals).forEach(k => {
    qText = qText.replace(new RegExp(`{${k}}`, 'g'), vals[k]);
    opts = opts.map(o => o.replace(new RegExp(`{${k}}`, 'g'), vals[k]));
  });

  return {
    q: qText,
    opts,
    ans: temp.ans,
    type: temp.type,
    chap: temp.chap,
    expl: temp.expl || 'Standard step-by-step conceptual answer.'
  };
}

// Auto-initialize state
function initCompState() {
  if (!D.compExam) {
    D.compExam = {
      configured: false,
      examId: 'jee_adv',
      targetScore: 280,
      dailyTime: 60,
      difficulty: 'medium'
    };
  }
  compState.examId = D.compExam.examId || 'jee_adv';
  compState.targetScore = D.compExam.targetScore || 280;
  compState.dailyTime = D.compExam.dailyTime || 60;
  compState.practiceDifficulty = D.compExam.difficulty || 'medium';
}

function saveCompState() {
  if (!D.compExam) D.compExam = {};
  D.compExam.examId = compState.examId;
  D.compExam.targetScore = compState.targetScore;
  D.compExam.dailyTime = compState.dailyTime;
  D.compExam.difficulty = compState.practiceDifficulty;
  D.compExam.configured = true;
  saveAll();
}

// Helper to trigger math formatting
function triggerMath() {
  setTimeout(() => {
    if (typeof renderMath === 'function') {
      renderMath();
    }
  }, 100);
}

// 🏁 Router Render Entry
function rComp() {
  initCompState();

  if (!D.compExam.configured) {
    renderOnboardingWizard();
    return;
  }

  const exam = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
  const targetPct = Math.round((compState.targetScore / exam.maxScore) * 100);

  let tabContent = '';
  switch (compState.currentTab) {
    case 'syllabus':
      tabContent = renderSyllabusTab(exam);
      break;
    case 'tips':
      tabContent = renderTipsTab(exam);
      break;
    case 'practice':
      tabContent = renderPracticeTab(exam);
      break;
    case 'mock':
      tabContent = renderMockTab(exam);
      break;
    case 'hub':
    default:
      tabContent = renderHubTab(exam, targetPct);
      break;
  }

  const main = document.getElementById('main');
  if (!main) return;

  main.innerHTML = `
    <div class="sw scr" style="padding-top:16px">
      <!-- Hub Banner -->
      <div class="card cglow mb20" style="padding:22px;position:relative;overflow:hidden;border:1px solid rgba(139,92,246,0.25);">
        <div style="position:absolute;top:-40px;right:-40px;width:120px;height:120px;background:radial-gradient(circle,rgba(139,92,246,0.3) 0%,transparent 70%);filter:blur(20px);z-index:0"></div>
        
        <div class="between" style="gap:16px;flex-wrap:wrap;position:relative;z-index:1">
          <div>
            <div class="h3" style="color:var(--pl);margin:0;font-size:11px;letter-spacing:1.5px;text-transform:uppercase">🏆 AI COMPETITIVE HUB</div>
            <div class="h1" style="color:#fff;margin:4px 0 6px 0;font-size:26px;display:flex;align-items:center;gap:10px">
              <span>${esc(exam.name)} Preparation</span>
              <span class="tag tp" style="font-size:11px;font-weight:700">${esc(exam.country)}</span>
            </div>
            <p class="sub" style="margin:0;max-width:550px">Pattern: ${esc(exam.pattern)}</p>
          </div>

          <button class="btn bsm bgh" onclick="reconfigureCompPlan()" style="display:flex;align-items:center;gap:6px">
            ⚙️ Reset Plan
          </button>
        </div>
      </div>

      <!-- Navigation Tabs -->
      <div style="display:flex;gap:8px;margin-bottom:20px;overflow-x:auto;padding-bottom:6px">
        <button class="btn bsm ${compState.currentTab==='hub'?'bpri':'bgh'}" onclick="setCompTab('hub')">📊 Study Hub</button>
        <button class="btn bsm ${compState.currentTab==='syllabus'?'bpri':'bgh'}" onclick="setCompTab('syllabus')">📚 Detailed Syllabus</button>
        <button class="btn bsm ${compState.currentTab==='tips'?'bpri':'bgh'}" onclick="setCompTab('tips')">💡 Formulas & Tactics</button>
        <button class="btn bsm ${compState.currentTab==='practice'?'bpri':'bgh'}" onclick="setCompTab('practice')">🎯 Custom Practice</button>
        <button class="btn bsm ${compState.currentTab==='mock'?'bpri':'bgh'}" onclick="setCompTab('mock')">⏱️ CBT Exam Room</button>
      </div>

      <!-- Tab Content -->
      <div class="reveal-step shown">
        ${tabContent}
      </div>
    </div>
  `;
  triggerMath();
}

// 🧙 Onboarding Personalization Wizard
function renderOnboardingWizard() {
  const main = document.getElementById('main');
  if (!main) return;

  const majorExams = WORLD_EXAMS.filter(e => e.isMajor);
  const filtered100 = filterExamsByQuery(compState.searchQuery);

  let stepHTML = '';

  if (compState.obStep === 1) {
    stepHTML = `
      <div class="h2 text-center mb14" style="color:#fff">1. Select Target Exam</div>
      <p class="sub text-center mb20" style="max-width:480px;margin:0 auto 20px">Search our database of the World's Top 100 Exams or choose from the list of major entrance tests.</p>
      
      <div style="position:relative;max-width:480px;margin:0 auto 20px">
        <span class="gsearch-icon" style="top:50%;transform:translateY(-50%)">🔍</span>
        <input type="text" id="exam-search" class="gsearch" style="padding-left:40px;background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.12)" placeholder="Search 100+ global exams (e.g. GMAT, Gaokao, CFA, GATE...)" value="${esc(compState.searchQuery)}" oninput="filterExams(this.value)">
        
        ${compState.searchQuery ? `
          <div id="exam-search-results" style="position:absolute;top:calc(100% + 6px);left:0;right:0;background:rgba(15,12,28,0.98);border:1px solid rgba(139,92,246,0.3);border-radius:12px;max-height:220px;overflow-y:auto;z-index:1000">
            ${filtered100.length > 0 ? filtered100.map(e => `
              <div class="gsugg-item" onclick="selectObExam('${e.id}')" style="padding:10px 14px;cursor:pointer;display:flex;justify-content:between;align-items:center;border-bottom:1px solid rgba(255,255,255,0.04)">
                <div>
                  <strong style="color:#fff">${esc(e.name)}</strong>
                  <span style="font-size:11px;color:var(--mut)"> · ${esc(e.cat)} (${esc(e.country)})</span>
                </div>
                <span class="tag tp" style="font-size:10px">Select</span>
              </div>
            `).join('') : `<div style="padding:14px;color:var(--mut);text-align:center;font-size:13px">No exams matched your search</div>`}
          </div>
        ` : ''}
      </div>

      <div class="grid-2" style="gap:12px;margin-bottom:20px">
        ${majorExams.map(e => `
          <div class="card card-lift cglow${compState.examId===e.id?' on':''}" onclick="selectObExam('${e.id}')" style="padding:16px;cursor:pointer;border-color:${compState.examId===e.id?'var(--p)':'var(--brd)'};background:${compState.examId===e.id?'rgba(139,92,246,0.06)':'rgba(255,255,255,0.02)'}">
            <div class="between mb6">
              <span style="font-weight:700;color:#fff;font-size:15px">${esc(e.name)}</span>
              <span class="tag tp" style="font-size:10px">${esc(e.cat)}</span>
            </div>
            <p style="font-size:12px;color:var(--mut);margin:0;line-height:1.4">${esc(e.pattern)}</p>
          </div>
        `).join('')}
      </div>

      <div style="text-align:right">
        <button class="btn bpri" onclick="navigateObStep(2)">Set Target Score →</button>
      </div>
    `;
  } else if (compState.obStep === 2) {
    const exam = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
    const minTarget = Math.round(exam.maxScore * 0.3);
    const targetPct = Math.round((compState.targetScore / exam.maxScore) * 100);

    stepHTML = `
      <div class="h2 text-center mb14" style="color:#fff">2. Set Target Score</div>
      <p class="sub text-center mb20">Select your benchmark target score for ${esc(exam.name)} (Max score: ${exam.maxScore})</p>

      <div class="card mb20" style="padding:22px;text-align:center">
        <div style="position:relative;width:120px;height:120px;margin:0 auto 16px">
          <svg width="120" height="120" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="50" stroke="rgba(255,255,255,0.05)" stroke-width="8" fill="none"></circle>
            <circle cx="60" cy="60" r="50" stroke="url(#obGlow)" stroke-width="8" fill="none"
              stroke-dasharray="314.16" stroke-dashoffset="${314.16 - (314.16 * targetPct) / 100}"
              stroke-linecap="round" style="transition:stroke-dashoffset 0.3s ease-out"></circle>
            <defs>
              <linearGradient id="obGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#8B5CF6"></stop>
                <stop offset="100%" stop-color="#06B6D4"></stop>
              </linearGradient>
            </defs>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <span style="font-size:22px;font-weight:800;color:#fff">${targetPct}%</span>
            <span style="font-size:9px;color:var(--mut);text-transform:uppercase">Percent</span>
          </div>
        </div>

        <div style="max-width:300px;margin:0 auto">
          <input type="range" min="${minTarget}" max="${exam.maxScore}" value="${compState.targetScore}" style="width:100%;accent-color:var(--p)" oninput="updateTargetVal(this.value)">
          <div class="between mt8" style="font-weight:700;font-size:16px;color:#fff">
            <span>Goal Score:</span>
            <span id="targetScoreDisplay" class="tag tp">${compState.targetScore}</span>
          </div>
        </div>
      </div>

      <div class="between">
        <button class="btn bgh" onclick="navigateObStep(1)">← Back</button>
        <button class="btn bpri" onclick="navigateObStep(3)">Commitments →</button>
      </div>
    `;
  } else if (compState.obStep === 3) {
    stepHTML = `
      <div class="h2 text-center mb14" style="color:#fff">3. Setup Prep Commitments</div>
      <p class="sub text-center mb20">Select your preferred study load and starting paper difficulty level.</p>

      <div class="card mb20" style="padding:22px">
        <div class="set-row">
          <div>
            <div style="color:#fff;font-weight:600">Daily Dedicated Prep</div>
            <div style="color:var(--mut);font-size:12px">Practice time recommendation</div>
          </div>
          <select class="inp" style="width:140px;padding:6px 10px" onchange="compState.dailyTime=parseInt(this.value)">
            <option value="30" ${compState.dailyTime==30?'selected':''}>30 Minutes</option>
            <option value="60" ${compState.dailyTime==60?'selected':''}>1 Hour</option>
            <option value="120" ${compState.dailyTime==120?'selected':''}>2 Hours</option>
          </select>
        </div>

        <div class="set-row">
          <div>
            <div style="color:#fff;font-weight:600">Initial Difficulty Level</div>
            <div style="color:var(--mut);font-size:12px">Practice & Mock initial level</div>
          </div>
          <select class="inp" style="width:140px;padding:6px 10px" onchange="compState.practiceDifficulty=this.value">
            <option value="easy" ${compState.practiceDifficulty==='easy'?'selected':''}>Easy</option>
            <option value="medium" ${compState.practiceDifficulty==='medium'?'selected':''}>Medium</option>
            <option value="hard" ${compState.practiceDifficulty==='hard'?'selected':''}>Hard</option>
            <option value="boss" ${compState.practiceDifficulty==='boss'?'selected':''}>😈 Boss Mode</option>
          </select>
        </div>
      </div>

      <div class="between">
        <button class="btn bgh" onclick="navigateObStep(2)">← Back</button>
        <button class="btn bpri" onclick="completeCompOnboarding()">🚀 Complete Personalization</button>
      </div>
    `;
  }

  main.innerHTML = `
    <div class="sw scr" style="padding-top:16px;max-width:560px;margin:0 auto">
      <div class="card cglow" style="padding:28px;border-color:rgba(139,92,246,0.3)">
        <div style="text-align:center;margin-bottom:24px">
          <div style="font-size:32px;margin-bottom:8px">🏆</div>
          <div class="h1" style="color:#fff;font-size:22px;margin:0">Configure Preparation Plan</div>
          <div style="display:flex;justify-content:center;gap:6px;margin-top:12px">
            <div style="width:24px;height:4px;border-radius:2px;background:${compState.obStep>=1?'var(--p)':'rgba(255,255,255,0.06)'}"></div>
            <div style="width:24px;height:4px;border-radius:2px;background:${compState.obStep>=2?'var(--p)':'rgba(255,255,255,0.06)'}"></div>
            <div style="width:24px;height:4px;border-radius:2px;background:${compState.obStep>=3?'var(--p)':'rgba(255,255,255,0.06)'}"></div>
          </div>
        </div>
        ${stepHTML}
      </div>
    </div>
  `;
  triggerMath();
}

function selectObExam(id) {
  compState.examId = id;
  const exam = WORLD_EXAMS.find(e => e.id === id);
  compState.targetScore = exam.isMajor ? exam.defaultTarget : Math.round(exam.maxScore * 0.8);
  compState.searchQuery = '';
  navigateObStep(2);
}

function filterExams(query) {
  compState.searchQuery = query;
  renderOnboardingWizard();
}

function filterExamsByQuery(q) {
  if (!q) return [];
  const cleanQ = q.toLowerCase().trim();
  return WORLD_EXAMS.filter(e => 
    e.name.toLowerCase().includes(cleanQ) || 
    e.cat.toLowerCase().includes(cleanQ) || 
    e.country.toLowerCase().includes(cleanQ)
  ).slice(0, 5);
}

function navigateObStep(step) {
  compState.obStep = step;
  renderOnboardingWizard();
}

function completeCompOnboarding() {
  saveCompState();
  rComp();
}

function reconfigureCompPlan() {
  D.compExam.configured = false;
  compState.obStep = 1;
  rComp();
}

// 1. Render Hub Tab
function renderHubTab(exam, targetPct) {
  return `
    <div style="display:grid;grid-template-columns:3fr 2fr;gap:20px">
      <div style="display:flex;flex-direction:column;gap:18px">
        <div class="card" style="padding:20px">
          <div class="h2 mb14" style="color:#fff;display:flex;align-items:center;gap:8px">⚙️ Preparation Parameters</div>
          
          <div class="set-row">
            <div>
              <div style="color:#fff;font-size:14px;font-weight:600">Target Score</div>
              <div style="color:var(--mut);font-size:12px">Your benchmark goal (Max: ${exam.maxScore})</div>
            </div>
            <div style="display:flex;align-items:center;gap:10px">
              <input type="range" min="${Math.round(exam.maxScore * 0.3)}" max="${exam.maxScore}" value="${compState.targetScore}" style="width:140px;accent-color:var(--p)" oninput="updateTargetVal(this.value)">
              <span id="targetScoreDisplay" class="tag tp" style="font-size:13px;font-weight:700;min-width:60px;text-align:center">${compState.targetScore}</span>
            </div>
          </div>

          <div class="set-row">
            <div>
              <div style="color:#fff;font-size:14px;font-weight:600">Daily Dedication</div>
              <div style="color:var(--mut);font-size:12px">Daily practice commitment time</div>
            </div>
            <select class="inp" style="width:140px;padding:6px 10px" onchange="updateDailyTime(this.value)">
              <option value="30" ${compState.dailyTime==30?'selected':''}>30 Minutes</option>
              <option value="60" ${compState.dailyTime==60?'selected':''}>1 Hour</option>
              <option value="120" ${compState.dailyTime==120?'selected':''}>2 Hours</option>
            </select>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="card card-lift cglow" style="padding:16px;cursor:pointer;background:linear-gradient(135deg,rgba(139,92,246,0.06),rgba(6,182,212,0.02));border-color:rgba(139,92,246,0.2)" onclick="setCompTab('practice')">
            <div style="font-size:28px;margin-bottom:8px">🎯</div>
            <div class="h3" style="color:#fff;margin-bottom:4px">Topic Practice</div>
            <p style="font-size:12px;color:var(--mut);margin:0;line-height:1.5">Customize difficulty levels and solve conceptual questions.</p>
          </div>
          <div class="card card-lift cglow" style="padding:16px;cursor:pointer;background:linear-gradient(135deg,rgba(6,182,212,0.06),rgba(236,72,153,0.02));border-color:rgba(6,182,212,0.2)" onclick="setCompTab('mock')">
            <div style="font-size:28px;margin-bottom:8px">⏱️</div>
            <div class="h3" style="color:#fff;margin-bottom:4px">CBT Exam Room</div>
            <p style="font-size:12px;color:var(--mut);margin:0;line-height:1.5">Simulate a timed mock exam with section tabs and marking scheme.</p>
          </div>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:18px">
        <div class="card" style="padding:20px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center">
          <div class="h3" style="color:var(--mut);font-size:12px;letter-spacing:1px;text-transform:uppercase;margin-bottom:12px">Calibration Progress</div>
          
          <div style="position:relative;width:130px;height:130px;margin-bottom:14px">
            <svg width="130" height="130" viewBox="0 0 130 130">
              <circle cx="65" cy="65" r="54" stroke="rgba(255,255,255,0.05)" stroke-width="8" fill="none"></circle>
              <circle cx="65" cy="65" r="54" stroke="url(#compGlow)" stroke-width="8" fill="none"
                stroke-dasharray="339.29" stroke-dashoffset="${339.29 - (339.29 * targetPct) / 100}"
                stroke-linecap="round" style="transition:stroke-dashoffset 0.6s ease-out"></circle>
              <defs>
                <linearGradient id="compGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#8B5CF6"></stop>
                  <stop offset="100%" stop-color="#06B6D4"></stop>
                </linearGradient>
              </defs>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
              <span style="font-size:24px;font-weight:800;color:#fff">${targetPct}%</span>
              <span style="font-size:10px;color:var(--mut);text-transform:uppercase;font-weight:700">Target</span>
            </div>
          </div>
          
          <div class="h3" style="color:#fff;margin:0 0 4px 0">Targeting ${compState.targetScore} / ${exam.maxScore}</div>
          <p style="font-size:12px;color:var(--mut);margin:0;line-height:1.4">Requires steady practice on high-yield sections.</p>
        </div>
      </div>
    </div>
  `;
}

// 2. Render Syllabus Tab
function renderSyllabusTab(exam) {
  const detailed = DETAILED_SYLLABUS[compState.examId];
  
  let syllabusHTML = '';
  if (detailed) {
    syllabusHTML = detailed.map(subj => `
      <div class="card mb20" style="padding:18px;border-color:rgba(139,92,246,0.18)">
        <div class="between mb12" style="border-bottom:1px solid var(--brd);padding-bottom:10px">
          <span style="font-size:16px;font-weight:800;color:var(--pl)">${esc(subj.subject)} Division</span>
          <span class="tag tp" style="font-size:11px">Weightage Map</span>
        </div>
        
        <div style="display:flex;flex-direction:column;gap:16px">
          ${subj.units.map(unit => `
            <div style="background:rgba(255,255,255,0.015);border:1px solid var(--brd);border-radius:10px;padding:12px 14px">
              <div class="between mb8">
                <span style="font-size:13px;font-weight:700;color:#fff">📦 ${esc(unit.name)}</span>
              </div>
              
              <div style="display:flex;flex-direction:column;gap:8px;padding-left:12px">
                ${unit.chapters.map(chap => `
                  <div>
                    <div class="between" style="font-size:12px;margin-bottom:2px">
                      <span style="color:var(--sub)">• ${esc(chap.name)}</span>
                      <span style="color:var(--cl);font-weight:600">${chap.weight}%</span>
                    </div>
                    <div class="pw" style="height:4px;background:rgba(255,255,255,0.03)">
                      <div class="pf" style="width:${chap.weight}%;background:linear-gradient(90deg,var(--p),var(--c))"></div>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');
  } else {
    const subjects = exam.subjects || ['General Studies'];
    syllabusHTML = subjects.map(subj => `
      <div class="card mb20" style="padding:18px">
        <div class="between mb12">
          <span style="font-size:15px;font-weight:700;color:var(--pl)">${esc(subj)} Syllabus</span>
          <span class="tag tp" style="font-size:11px">Standard Weight</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          <div style="background:rgba(255,255,255,0.02);padding:10px;border-radius:8px">
            <div class="between mb6" style="font-size:12px;font-weight:700;color:#fff">
              <span>Unit 1: Fundamentals & Theory</span>
              <span>45%</span>
            </div>
            <div class="pw" style="height:4px;background:rgba(255,255,255,0.04)">
              <div class="pf" style="width:45%;background:var(--p)"></div>
            </div>
          </div>
          <div style="background:rgba(255,255,255,0.02);padding:10px;border-radius:8px">
            <div class="between mb6" style="font-size:12px;font-weight:700;color:#fff">
              <span>Unit 2: Advanced Integration & Applications</span>
              <span>55%</span>
            </div>
            <div class="pw" style="height:4px;background:rgba(255,255,255,0.04)">
              <div class="pf" style="width:55%;background:var(--c)"></div>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  }

  return `
    <div class="card" style="padding:22px">
      <div class="h2 mb6" style="color:#fff">📚 Detailed Syllabus Weightage Board</div>
      <p class="sub mb20">Explore subject-wise, unit-wise, and chapter-wise breakdowns calculated from past official papers.</p>
      ${syllabusHTML}
    </div>
  `;
}

// 3. Render Tips & Tricks Tab
function renderTipsTab(exam) {
  return `
    <div style="display:grid;grid-template-columns:3fr 2fr;gap:20px">
      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card" style="padding:18px">
          <div class="h2 mb12" style="color:#fff">📝 High-Yield Formulas (LaTeX Rendered)</div>
          
          <div style="display:flex;flex-direction:column;gap:14px">
            <div style="background:rgba(255,255,255,0.015);padding:14px;border-radius:10px;border:1px solid var(--brd)">
              <span class="tag tp mb6" style="font-size:10px">Mathematics (Calculus/Algebra)</span>
              <div style="font-size:16px;color:#fff;margin:8px 0;text-align:center">
                $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$
              </div>
              <p style="font-size:12px;color:var(--mut);margin:0">Quadratic solution formula. Essential for algebra roots calculation.</p>
            </div>

            <div style="background:rgba(255,255,255,0.015);padding:14px;border-radius:10px;border:1px solid var(--brd)">
              <span class="tag tp mb6" style="font-size:10px">Physics (Modern / Quantum)</span>
              <div style="font-size:16px;color:#fff;margin:8px 0;text-align:center">
                $E = mc^2 \\quad \\text{and} \\quad \\lambda = \\frac{h}{p}$
              </div>
              <p style="font-size:12px;color:var(--mut);margin:0">Mass-energy equivalence and De Broglie wavelength equations.</p>
            </div>

            <div style="background:rgba(255,255,255,0.015);padding:14px;border-radius:10px;border:1px solid var(--brd)">
              <span class="tag tp mb6" style="font-size:10px">Chemistry (Physical / Kinetics)</span>
              <div style="font-size:16px;color:#fff;margin:8px 0;text-align:center">
                $PV = nRT \\quad \\text{and} \\quad K = A e^{-\\frac{E_a}{RT}}$
              </div>
              <p style="font-size:12px;color:var(--mut);margin:0">Ideal gas equation and Arrhenius rate constant equation.</p>
            </div>
          </div>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card" style="padding:18px">
          <div class="h2 mb12" style="color:#fff">⏱️ Strategic CBT Tactics</div>
          
          <div style="display:flex;flex-direction:column;gap:12px;font-size:13px;line-height:1.5;color:var(--sub)">
            <div style="border-left:3px solid var(--p);padding-left:10px">
              <strong style="color:#fff">The 3-Pass Method:</strong>
              <div>Pass 1: Direct conceptual / fast questions. Pass 2: Solvable but calculation-heavy. Pass 3: Hard / complex problems.</div>
            </div>
            <div style="border-left:3px solid var(--c);padding-left:10px">
              <strong style="color:#fff">Option Elimination:</strong>
              <div>Identify dimensional mismatches, evaluate extreme conditions ($x \\to 0, \\infty$), and eliminate distractors before solving.</div>
            </div>
            <div style="border-left:3px solid var(--okl);padding-left:10px">
              <strong style="color:#fff">Save & Next Habit:</strong>
              <div>In computer-based tests, always click "Save & Next" to record answers. Do not leave them pending in review state.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

// 4. Render Practice Tab
function renderPracticeTab(exam) {
  const subjects = exam.subjects || ['General Studies'];
  if (!compState.practiceSubject) compState.practiceSubject = subjects[0];

  return `
    <div class="card" style="padding:22px">
      <div class="h2 mb14" style="color:#fff">🎯 Custom Practice Room</div>
      <p class="sub mb20">Select any syllabus subject and customize your target difficulty to generate adaptive AI-powered questions.</p>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
        <div>
          <label class="inp-label">SECTION / SUBJECT</label>
          <select class="inp" onchange="compState.practiceSubject=this.value">
            ${subjects.map(s => `<option value="${s}" ${compState.practiceSubject===s?'selected':''}>${s}</option>`).join('')}
          </select>
        </div>

        <div>
          <label class="inp-label">DIFFICULTY</label>
          <select class="inp" onchange="compState.practiceDifficulty=this.value">
            <option value="easy" ${compState.practiceDifficulty==='easy'?'selected':''}>Easy</option>
            <option value="medium" ${compState.practiceDifficulty==='medium'?'selected':''}>Medium</option>
            <option value="hard" ${compState.practiceDifficulty==='hard'?'selected':''}>Hard</option>
            <option value="boss" ${compState.practiceDifficulty==='boss'?'selected':''}>😈 Boss Mode</option>
          </select>
        </div>
      </div>

      <div style="text-align:center;padding:12px 0">
        <button id="start-practice-btn" class="btn bpri blg" style="padding:13px 36px;font-size:15px" onclick="startCompPractice()">
          🚀 Launch Practice Question
        </button>
      </div>
    </div>
  `;
}

// 5. Render Mock Exam Tab
function renderMockTab(exam) {
  if (compState.activeExam) {
    if (!compState.activeExam.instructionsRead) {
      return renderMockInstructions(exam);
    }
    return renderActiveExamUI();
  }

  // Calculate actual questions count and actual duration
  const fullQuestionsCount = exam.fullQuestions || 50;
  const fullDurationMin = exam.duration || 120;

  return `
    <div class="card" style="padding:22px;text-align:center;max-width:550px;margin:0 auto">
      <div style="font-size:54px;margin-bottom:14px">⏱️</div>
      <div class="h2" style="color:#fff;margin-bottom:8px">CBT Exam Room</div>
      <p class="sub mb20">Launch a professional computer-based mock exam simulator mapped exactly to the real paper pattern.</p>

      <div class="card mb20" style="background:rgba(255,255,255,0.02);padding:18px;text-align:left">
        <div style="font-size:13px;color:#fff;font-weight:700;margin-bottom:12px">Choose Simulation Mode:</div>
        
        <div style="display:flex;flex-direction:column;gap:10px">
          <label style="display:flex;align-items:start;gap:10px;cursor:pointer">
            <input type="radio" name="mock-mode-select" value="diagnostic" checked style="margin-top:4px;accent-color:var(--p)">
            <div>
              <div style="color:#fff;font-weight:600;font-size:13px">⚡ Diagnostic Test (6 Questions · 10 Mins)</div>
              <div style="font-size:11px;color:var(--mut)">Fast, high-fidelity AI-curated paper across all subjects. Ideal for quick check.</div>
            </div>
          </label>
          
          <label style="display:flex;align-items:start;gap:10px;cursor:pointer;margin-top:6px">
            <input type="radio" name="mock-mode-select" value="full" style="margin-top:4px;accent-color:var(--p)">
            <div>
              <div style="color:#fff;font-weight:600;font-size:13px">🏆 Full Exam Simulation (Exact ${fullQuestionsCount} Qs · ${fullDurationMin} Mins)</div>
              <div style="font-size:11px;color:var(--mut)">Realistic CBT simulator matching the exact questions count, section weights, and exam duration.</div>
            </div>
          </label>
        </div>
      </div>

      <button id="launch-mock-btn" class="btn bpri blg w100" style="padding:14px 28px;font-size:15px" onclick="startMockExamSetup()">
        🔥 Launch Mock Simulation
      </button>
    </div>
  `;
}

// Mock Exam Instructions Page
function renderMockInstructions(exam) {
  const mode = compState.activeExam.mode;
  const isFull = mode === 'full';
  const duration = isFull ? (exam.duration || 120) : 10;
  const questionsCount = isFull ? (exam.fullQuestions || 50) : 6;

  return `
    <div class="card cglow" style="padding:26px;max-width:600px;margin:0 auto;border-color:rgba(139,92,246,0.3)">
      <div class="h1" style="color:#fff;text-align:center;margin-bottom:18px">Examination Instructions</div>
      
      <div style="font-size:13px;color:var(--sub);line-height:1.6;display:flex;flex-direction:column;gap:12px;margin-bottom:20px">
        <div>Please read the following guidelines carefully before starting the CBT:</div>
        
        <div style="background:rgba(255,255,255,0.02);padding:12px;border-radius:8px">
          <strong style="color:#fff">1. Timer & Navigation:</strong>
          <div>The test duration is <strong>${duration} minutes</strong>. The countdown timer starts immediately upon clicking the begin button. You can switch between questions and sections at any point.</div>
        </div>

        <div style="background:rgba(255,255,255,0.02);padding:12px;border-radius:8px">
          <strong style="color:#fff">2. CBT Color Scheme & Symbols:</strong>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px">
            <div><span class="btn bsm bgh" style="min-height:auto;padding:2px 8px;font-size:10px">1</span> Not Visited</div>
            <div><span class="btn bsm" style="min-height:auto;padding:2px 8px;font-size:10px;background:#EF4444;color:#fff">1</span> Visited but Unanswered</div>
            <div><span class="btn bsm" style="min-height:auto;padding:2px 8px;font-size:10px;background:#10B981;color:#fff">1</span> Saved & Answered</div>
            <div><span class="btn bsm" style="min-height:auto;padding:2px 8px;font-size:10px;background:#F59E0B;color:#fff">1</span> Marked for Review</div>
          </div>
        </div>

        <div style="background:rgba(255,255,255,0.02);padding:12px;border-radius:8px">
          <strong style="color:#fff">3. Scoring Scheme:</strong>
          <div>Correct Answer: <strong>+${exam.marking.correct}</strong>. Incorrect: <strong>${exam.marking.wrong}</strong>. Unattempted: <strong>0</strong>. (Negative markings applied).</div>
        </div>
      </div>

      <div style="margin-bottom:20px;display:flex;align-items:center;gap:10px">
        <input type="checkbox" id="instructions-agree-check" style="width:16px;height:16px;accent-color:var(--p)">
        <label for="instructions-agree-check" style="font-size:12px;color:#fff;cursor:pointer;font-weight:600">I have read, understood, and agree to follow all instructions.</label>
      </div>

      <div class="between">
        <button class="btn bgh" onclick="cancelMockExamSetup()">Cancel</button>
        <button class="btn bpri" onclick="beginMockExamAfterInstructions()">🚀 BEGIN EXAMINATION</button>
      </div>
    </div>
  `;
}

function cancelMockExamSetup() {
  compState.activeExam = null;
  rComp();
}

function beginMockExamAfterInstructions() {
  const check = document.getElementById('instructions-agree-check');
  if (!check || !check.checked) {
    alert('Please check the box to confirm you have read the instructions.');
    return;
  }
  
  compState.activeExam.instructionsRead = true;
  rComp();
}

// ⏱️ CBT Mock Setup
async function startMockExamSetup() {
  const btn = document.getElementById('launch-mock-btn');
  const checkedRadio = document.querySelector('input[name="mock-mode-select"]:checked');
  const mode = checkedRadio ? checkedRadio.value : 'diagnostic';

  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '✨ Assembling CBT paper and formulas...';
  }

  const exam = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
  const diff = compState.practiceDifficulty;
  const subjects = exam.subjects || ['General Studies'];

  let questions = [];
  let durationSeconds = 600; // default 10 minutes

  if (mode === 'full') {
    // Exact Questions Count & Exact Duration!
    const fullQuestionsCount = exam.fullQuestions || 50;
    const fullDurationMin = exam.duration || 120;
    durationSeconds = fullDurationMin * 60;

    questions = generateProceduralMockQuestions(exam, fullQuestionsCount);
  } else {
    // Diagnostic 6 Qs
    durationSeconds = 600;
    const prompt = `Generate exactly 6 realistic, syllabus-matched exam questions for the "${exam.name}" exam.
Subjects/Sections: ${subjects.join(', ')}
Difficulty level: ${diff}

Return ONLY a JSON object containing a "questions" array with exactly 6 questions matching this structure:
{
  "questions": [
    {
      "section": "Section name matching one of the requested sections exactly",
      "q": "The question text, write math symbols in LaTeX format like $x^2$ or $\\int$ if applicable",
      "type": "mcq" | "msq" | "numerical",
      "opts": ["Option A", "Option B", "Option C", "Option D"],
      "ans": [0], // array of correct indices or single string/fraction for numerical
      "expl": "Detailed step-by-step solution"
    }
  ]
}`;

    try {
      const sys = "You are a professional examiner. Output valid JSON.";
      const reply = await ai([{ role: 'user', content: prompt }], sys, 2000, true);
      
      if (reply) {
        // Escaping backslashes before JSON parse to protect LaTeX symbols
        const escapedReply = escapeJsonLatex(reply);
        const data = JSON.parse(escapedReply);
        if (data && data.questions && data.questions.length > 0) {
          questions = data.questions;
        }
      }
    } catch (e) {
      console.warn('[Comp Exam] AI mock generation failed, using local database:', e);
    }

    if (questions.length === 0) {
      const list = OFFLINE_EXAM_QUESTIONS[compState.examId] || OFFLINE_EXAM_QUESTIONS.jee_adv;
      questions = list.map((q, idx) => ({ ...q, id: idx + 1 }));
    } else {
      questions = questions.map((q, idx) => ({ ...q, id: idx + 1 }));
    }
  }

  compState.activeExam = {
    questions,
    currentIndex: 0,
    answers: {},
    status: {}, 
    timeLeft: durationSeconds,
    timerInterval: null,
    instructionsRead: false,
    mode
  };

  // Visited first question
  compState.activeExam.status[0] = 'unanswered';

  // Timer countdown
  compState.activeExam.timerInterval = setInterval(() => {
    if (compState.activeExam && compState.activeExam.instructionsRead) {
      compState.activeExam.timeLeft--;
      if (compState.activeExam.timeLeft <= 0) {
        submitMockExam();
      } else {
        updateExamTimerDisplay();
      }
    }
  }, 1000);

  rComp();
}

function updateExamTimerDisplay() {
  const el = document.getElementById('exam-timer-text');
  if (el && compState.activeExam) {
    const m = Math.floor(compState.activeExam.timeLeft / 60);
    const s = compState.activeExam.timeLeft % 60;
    el.textContent = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
}

// CBT Simulator UI
function renderActiveExamUI() {
  const exam = compState.activeExam;
  if (!exam) return '';

  const q = exam.questions[exam.currentIndex];
  const examDb = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
  const sections = examDb.subjects || ['General'];
  
  const m = Math.floor(exam.timeLeft / 60);
  const s = exam.timeLeft % 60;
  const timeStr = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  const isTimeCritical = exam.timeLeft < 120;

  return `
    <div style="display:grid;grid-template-columns:3fr 1fr;gap:20px">
      <!-- Left: Active Question -->
      <div class="card cglow" style="padding:22px;border-color:rgba(139,92,246,0.3)">
        <!-- Section Tabs -->
        <div style="display:flex;gap:6px;margin-bottom:18px;border-bottom:1px solid var(--brd);padding-bottom:10px;overflow-x:auto">
          ${sections.map(sec => {
            const isCurrentSec = q.section === sec;
            return `
              <span class="tag ${isCurrentSec?'tp':'tgray'}" style="cursor:pointer;font-weight:700;font-size:12px;padding:6px 12px;white-space:nowrap" onclick="switchMockSection('${sec}')">
                ${sec}
              </span>
            `;
          }).join('')}
        </div>

        <!-- Question Content -->
        <div style="font-size:15px;color:#fff;font-weight:500;line-height:1.6;margin-bottom:20px;white-space:pre-line" class="katex-render-target">
          ${esc(q.q)}
        </div>

        <!-- Answers -->
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
          ${q.type === 'numerical' ? `
            <div style="display:flex;flex-direction:column;gap:8px">
              <span style="font-size:11px;color:var(--mut);font-weight:700">ENTER EXACT NUMERICAL ANSWER:</span>
              <input type="text" id="numerical-ans-input" class="inp" placeholder="e.g. -1/6 or 4" value="${exam.answers[exam.currentIndex] || ''}" oninput="saveNumericalAnswer(this.value)">
            </div>
          ` : q.opts.map((opt, oIdx) => {
            let isSelected = false;
            if (q.type === 'msq') {
              isSelected = (exam.answers[exam.currentIndex] || []).includes(oIdx);
            } else {
              isSelected = exam.answers[exam.currentIndex] === oIdx;
            }

            return `
              <div class="qopt${isSelected?' on':''}" onclick="selectMockOption(${oIdx}, '${q.type}')" style="padding:14px 18px;border-radius:12px;background:rgba(255,255,255,0.03);border:1px solid ${isSelected?'var(--p)':'var(--brd)'};cursor:pointer;color:${isSelected?'#fff':'var(--sub)'};font-size:14px;display:flex;align-items:center;gap:12px">
                <div style="width:20px;height:20px;border-radius:50%;border:1px solid ${isSelected?'var(--p)':'rgba(255,255,255,0.2)'};display:flex;align-items:center;justify-content:center;font-size:11px;background:${isSelected?'var(--p)':'transparent'};color:#fff">
                  ${String.fromCharCode(65 + oIdx)}
                </div>
                <div class="katex-render-target">${esc(opt)}</div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Controls -->
        <div class="between" style="border-top:1px solid var(--brd);padding-top:18px">
          <button class="btn bsec" onclick="clearActiveExamAnswer()">Clear Response</button>
          <div style="display:flex;gap:8px">
            <button class="btn bgh" onclick="markMockForReview()">Mark for Review & Next</button>
            <button class="btn bpri" onclick="saveAndNextMock()">Save & Next</button>
          </div>
        </div>
      </div>

      <!-- Right Panel: Grid & Timer -->
      <div style="display:flex;flex-direction:column;gap:18px">
        <div class="card" style="padding:16px;text-align:center;border-color:${isTimeCritical?'#EF4444':'var(--brd)'}">
          <span style="font-size:11px;font-weight:700;color:var(--mut);letter-spacing:0.5px">TIME REMAINING</span>
          <div id="exam-timer-text" style="font-size:28px;font-family:monospace;font-weight:800;color:${isTimeCritical?'#EF4444':'#fff'};margin-top:6px">
            ${timeStr}
          </div>
        </div>

        <!-- Scrollable Grid Panel -->
        <div class="card" style="padding:16px">
          <span style="font-size:11px;font-weight:700;color:var(--mut);letter-spacing:0.5px;display:block;margin-bottom:12px">QUESTION PALETTE</span>
          
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-height:220px;overflow-y:auto;padding-right:4px;margin-bottom:14px">
            ${exam.questions.map((_, idx) => {
              const status = exam.status[idx] || 'unvisited';
              let btnClass = 'bgh';
              if (status === 'unanswered') btnClass = 'btn-red';
              if (status === 'answered') btnClass = 'bok';
              if (status === 'marked') btnClass = 'btn-gold';
              
              const isCurrent = exam.currentIndex === idx;
              const borderStyle = isCurrent ? 'border: 2px solid var(--p) !important;' : '';

              return `
                <button class="btn bsm ${btnClass}" style="min-height:34px;${borderStyle}" onclick="navigateExam(${idx})">
                  ${idx + 1}
                </button>
              `;
            }).join('')}
          </div>

          <div style="font-size:10px;color:var(--mut);display:grid;grid-template-columns:1fr 1fr;gap:6px;border-top:1px dashed var(--brd);padding-top:10px">
            <div style="display:flex;align-items:center;gap:4px">
              <span style="width:10px;height:10px;background:rgba(255,255,255,0.06);border-radius:2px;display:inline-block"></span> Unvisited
            </div>
            <div style="display:flex;align-items:center;gap:4px">
              <span style="width:10px;height:10px;background:#EF4444;border-radius:2px;display:inline-block"></span> Unanswered
            </div>
            <div style="display:flex;align-items:center;gap:4px">
              <span style="width:10px;height:10px;background:#10B981;border-radius:2px;display:inline-block"></span> Answered
            </div>
            <div style="display:flex;align-items:center;gap:4px">
              <span style="width:10px;height:10px;background:#F59E0B;border-radius:2px;display:inline-block"></span> Marked
            </div>
          </div>
        </div>

        <button class="btn bpri w100" style="padding:12px;font-weight:700;background:#EF4444" onclick="confirmSubmitMockExam()">
          🏁 Submit Examination
        </button>
      </div>
    </div>
  `;
}

function switchMockSection(sec) {
  const exam = compState.activeExam;
  if (!exam) return;
  const targetIdx = exam.questions.findIndex(q => q.section === sec);
  if (targetIdx !== -1) {
    navigateExam(targetIdx);
  }
}

function markMockForReview() {
  const exam = compState.activeExam;
  if (!exam) return;
  exam.status[exam.currentIndex] = 'marked';
  
  if (exam.currentIndex < exam.questions.length - 1) {
    navigateExam(exam.currentIndex + 1);
  } else {
    rComp();
  }
}

function saveAndNextMock() {
  const exam = compState.activeExam;
  if (!exam) return;
  
  const userAns = exam.answers[exam.currentIndex];
  if (userAns !== undefined && userAns !== '') {
    exam.status[exam.currentIndex] = 'answered';
  } else {
    exam.status[exam.currentIndex] = 'unanswered';
  }

  if (exam.currentIndex < exam.questions.length - 1) {
    navigateExam(exam.currentIndex + 1);
  } else {
    rComp();
  }
}

function confirmSubmitMockExam() {
  const exam = compState.activeExam;
  if (!exam) return;

  const total = exam.questions.length;
  let answered = 0;
  for (let i = 0; i < total; i++) {
    if (exam.status[i] === 'answered') answered++;
  }
  const unanswered = total - answered;

  const msg = `Are you sure you want to submit? \n\n• Total Questions: ${total}\n• Saved Answers: ${answered}\n• Unanswered / Marked: ${unanswered}\n\nYou cannot modify your answers after submitting.`;
  if (confirm(msg)) {
    submitMockExam();
  }
}

function submitMockExam() {
  const exam = compState.activeExam;
  if (!exam) return;

  clearInterval(exam.timerInterval);
  
  const examDb = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
  const marking = examDb.marking || { correct: 4, wrong: -1 };

  let score = 0;
  let correct = 0;
  let incorrect = 0;
  let skipped = 0;
  
  const results = exam.questions.map((q, idx) => {
    const userAns = exam.answers[idx];
    let isCorrect = false;
    
    if (userAns === undefined || userAns === '') {
      skipped++;
    } else {
      if (q.type === 'msq') {
        const sortedUser = (userAns || []).slice().sort().join(',');
        const sortedCorrect = (q.ans || []).slice().sort().join(',');
        isCorrect = sortedUser === sortedCorrect;
      } else if (q.type === 'numerical') {
        isCorrect = String(userAns).trim() === String(q.ans).trim();
      } else {
        isCorrect = userAns === q.ans[0];
      }
      
      if (isCorrect) {
        correct++;
        score += marking.correct;
      } else {
        incorrect++;
        score += marking.wrong;
      }
    }
    
    return {
      q: q.q,
      user: userAns,
      correct: q.opts ? q.opts[q.ans[0]] || q.ans.map(a => q.opts[a]).join(', ') : q.ans,
      isCorrect,
      explanation: q.expl || 'Self-explanatory standard answer.'
    };
  });

  const xpEarned = correct * 30;
  if (xpEarned > 0 && typeof addXP === 'function') {
    addXP(xpEarned);
  }

  compState.activeExam = null;
  renderMockScorecard(score, correct, incorrect, skipped, results, xpEarned);
}

function renderMockScorecard(score, correct, incorrect, skipped, results, xpEarned) {
  const main = document.getElementById('main');
  if (!main) return;

  const targetScore = compState.targetScore;
  const isTargetAchieved = score >= targetScore;
  
  main.innerHTML = `
    <div class="sw scr" style="padding-top:16px">
      <div class="card cglow mb20" style="padding:26px;text-align:center;border-color:${isTargetAchieved?'rgba(16,185,129,0.3)':'rgba(139,92,246,0.3)'};background:${isTargetAchieved?'rgba(16,185,129,0.03)':'rgba(139,92,246,0.03)'}">
        <div style="font-size:54px;margin-bottom:12px">${isTargetAchieved?'🏆':'📊'}</div>
        <div class="h1" style="color:#fff;margin-bottom:8px">Mock Scorecard</div>
        
        <div class="between" style="max-width:400px;margin:0 auto 24px;gap:20px">
          <div class="card" style="flex:1;padding:16px;background:rgba(255,255,255,0.02)">
            <span style="font-size:11px;font-weight:700;color:var(--mut)">YOUR SCORE</span>
            <div class="h1" style="color:#fff;margin:8px 0 0 0;font-size:36px">${Math.round(score * 100) / 100}</div>
          </div>
          <div class="card" style="flex:1;padding:16px;background:rgba(255,255,255,0.02)">
            <span style="font-size:11px;font-weight:700;color:var(--mut)">TARGET SCORE</span>
            <div class="h1" style="color:#fff;margin:8px 0 0 0;font-size:36px">${targetScore}</div>
          </div>
        </div>

        <div style="display:flex;justify-content:center;gap:20px;font-size:13px;color:var(--sub);margin-bottom:20px">
          <div>✅ Correct: <strong style="color:var(--okl)">${correct}</strong></div>
          <div>❌ Incorrect: <strong style="color:var(--redl)">${incorrect}</strong></div>
          <div>⚪ Skipped: <strong>${skipped}</strong></div>
          <div>⚡ XP: <strong style="color:var(--pl)">+${xpEarned}</strong></div>
        </div>

        <button class="btn bpri" style="padding:10px 24px" onclick="rComp()">Back to Hub</button>
      </div>

      <div class="h2 mb14" style="color:#fff">Review Questions & Explanations</div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${results.map((res, idx) => `
          <div class="card" style="padding:16px;border:1px solid ${res.isCorrect?'rgba(16,185,129,0.2)':'rgba(239,68,68,0.2)'}">
            <div class="between mb8" style="font-size:12px">
              <span style="font-weight:700;color:var(--mut)">Question ${idx + 1}</span>
              <span class="tag ${res.isCorrect?'tok':'tred'}">${res.isCorrect?'Correct':'Incorrect'}</span>
            </div>
            <p style="font-size:13px;color:#fff;line-height:1.5;margin-bottom:12px;white-space:pre-line" class="katex-render-target">${esc(res.q)}</p>
            
            <div style="font-size:12px;color:var(--sub);margin-bottom:8px">
              Your Answer: <strong style="color:${res.isCorrect?'var(--okl)':'var(--redl)'}">${res.user !== undefined && res.user !== '' ? (res.user.join ? res.user.map(u => String.fromCharCode(65+u)).join(', ') : (isNaN(res.user) ? res.user : String.fromCharCode(65+res.user))) : 'Skipped'}</strong>
            </div>

            <div style="font-size:12px;color:var(--sub);background:rgba(255,255,255,0.02);padding:10px;border-radius:8px" class="katex-render-target">
              <span style="font-weight:700;color:#fff;display:block;margin-bottom:4px">Solution Details:</span>
              ${esc(res.explanation)}
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  triggerMath();
}

// 🎯 Practice Overlay
function launchPracticeOverlay(q) {
  const existing = document.getElementById('practice-modal');
  if (existing) existing.remove();

  const wrap = document.createElement('div');
  wrap.id = 'practice-modal';
  wrap.className = 'modal-bg';
  
  wrap.innerHTML = `
    <div class="modal-box" style="max-width:500px;padding:24px">
      <div class="between mb14" style="border-bottom:1px solid var(--brd);padding-bottom:10px">
        <span class="tag tp" style="font-weight:700">🎯 Practice Question</span>
        <button class="btn bsm bsec" onclick="closePracticeOverlay()" style="min-height:auto;padding:4px 8px">Close</button>
      </div>

      <div style="font-size:14px;color:#fff;font-weight:500;line-height:1.6;margin-bottom:16px;white-space:pre-line" class="katex-render-target">
        ${esc(q.q)}
      </div>

      <div id="practice-hint-box" style="display:none;background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:10px;padding:10px;font-size:12px;color:var(--goldl);margin-bottom:14px" class="katex-render-target">
        <strong>Hint:</strong> ${esc(q.hint || 'Analyze the question parameters carefully.')}
      </div>

      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">
        ${q.type === 'numerical' ? `
          <div style="display:flex;flex-direction:column;gap:6px">
            <span style="font-size:11px;color:var(--mut);font-weight:700">ENTER VALUE:</span>
            <input type="text" id="practice-num-input" class="inp" placeholder="e.g. -1/6 or 4">
          </div>
        ` : (q.opts || []).map((opt, idx) => `
          <button class="btn bsm bgh w100" style="text-align:left;justify-content:flex-start;padding:12px 14px;font-size:13px;display:flex;align-items:center;gap:8px" onclick="checkPracticeAnswer(${idx}, ${JSON.stringify(q.ans)}, '${escON(q.expl || '')}')">
            <span>${String.fromCharCode(65 + idx)}.</span>
            <span class="katex-render-target">${esc(opt)}</span>
          </button>
        `).join('')}
      </div>

      ${q.type === 'numerical' ? `
        <button class="btn bpri w100 mb12" onclick="checkPracticeNumericalAnswer('${q.ans}', '${escON(q.expl || '')}')">Submit Answer</button>
      ` : ''}

      <div class="between">
        <button class="btn bgh bsm" onclick="document.getElementById('practice-hint-box').style.display='block'">💡 Need a Hint?</button>
        <div id="practice-result-text" style="font-size:13px;font-weight:700"></div>
      </div>

      <div id="practice-expl-box" style="display:none;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);border-radius:10px;padding:12px;font-size:12px;color:var(--okl);margin-top:14px" class="katex-render-target">
        <strong>Solution:</strong> <span id="practice-expl-text"></span>
      </div>
    </div>
  `;
  document.body.appendChild(wrap);
  triggerMath();
}

function closePracticeOverlay() {
  const el = document.getElementById('practice-modal');
  if (el) el.remove();
}

function checkPracticeAnswer(idx, correctAnswers, expl) {
  const resultText = document.getElementById('practice-result-text');
  const explBox = document.getElementById('practice-expl-box');
  const explText = document.getElementById('practice-expl-text');
  
  const isCorrect = correctAnswers.includes(idx);

  if (resultText) {
    if (isCorrect) {
      resultText.textContent = '🎉 Correct! +25 XP';
      resultText.style.color = 'var(--okl)';
      if (typeof addXP === 'function') addXP(25);
    } else {
      resultText.textContent = '❌ Incorrect. Try again!';
      resultText.style.color = 'var(--redl)';
    }
  }

  if (explBox && explText) {
    explText.textContent = expl;
    explBox.style.display = 'block';
  }
  triggerMath();
}

function checkPracticeNumericalAnswer(correctAns, expl) {
  const input = document.getElementById('practice-num-input');
  if (!input) return;

  const userVal = input.value.trim();
  const resultText = document.getElementById('practice-result-text');
  const explBox = document.getElementById('practice-expl-box');
  const explText = document.getElementById('practice-expl-text');

  const isCorrect = String(userVal) === String(correctAns);

  if (resultText) {
    if (isCorrect) {
      resultText.textContent = '🎉 Correct! +25 XP';
      resultText.style.color = 'var(--okl)';
      if (typeof addXP === 'function') addXP(25);
    } else {
      resultText.textContent = `❌ Incorrect. Correct is ${correctAns}.`;
      resultText.style.color = 'var(--redl)';
    }
  }

  if (explBox && explText) {
    explText.textContent = expl;
    explBox.style.display = 'block';
  }
  triggerMath();
}

async function startCompPractice() {
  const btn = document.getElementById('start-practice-btn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '✨ Generating Practice Question...';
  }

  const exam = WORLD_EXAMS.find(e => e.id === compState.examId) || WORLD_EXAMS[0];
  const section = compState.practiceSubject;
  const diff = compState.practiceDifficulty;

  const prompt = `Generate exactly 1 high-fidelity exam question for the "${exam.name}" exam.
Section: ${section}
Difficulty level: ${diff} (easy, medium, hard, or boss-mode)
Question Type: Choose appropriately based on the exam's real patterns (can be mcq, msq, or numerical).

Return ONLY a JSON object matching this structure:
{
  "q": "The question text, write math symbols in LaTeX format like $x^2$ or $\\int$ if applicable",
  "opts": ["Option A", "Option B", "Option C", "Option D"], // empty for numerical
  "ans": [0], // array of correct indices for MCQ/MSQ (0-indexed), or string/number value for numerical
  "type": "mcq" | "msq" | "numerical",
  "hint": "Conceptual hint",
  "expl": "Step-by-step solution details"
}`;

  try {
    const sys = "You are a professional examiner. Output valid JSON.";
    const reply = await ai([{ role: 'user', content: prompt }], sys, 1000, true);
    
    if (reply) {
      const escapedReply = escapeJsonLatex(reply);
      const q = JSON.parse(escapedReply);
      launchPracticeOverlay(q);
    }
  } catch (err) {
    console.warn('[Comp Exam] AI practice generation failed, falling back to local database:', err);
    const list = OFFLINE_EXAM_QUESTIONS[compState.examId] || OFFLINE_EXAM_QUESTIONS.jee_adv;
    launchPracticeOverlay(list[0]);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '🚀 Generate Practice Question';
    }
  }
}

// CBT Navigation Helpers
function navigateExam(idx) {
  if (compState.activeExam) {
    if (!compState.activeExam.status[compState.activeExam.currentIndex]) {
      compState.activeExam.status[compState.activeExam.currentIndex] = 'unanswered';
    }
    
    compState.activeExam.currentIndex = idx;
    
    if (!compState.activeExam.status[idx]) {
      compState.activeExam.status[idx] = 'unanswered';
    }
    
    rComp();
  }
}

function selectMockOption(oIdx, type) {
  const exam = compState.activeExam;
  if (!exam) return;
  
  if (type === 'msq') {
    let current = exam.answers[exam.currentIndex] || [];
    const valIdx = current.indexOf(oIdx);
    if (valIdx === -1) {
      current.push(oIdx);
    } else {
      current.splice(valIdx, 1);
    }
    if (current.length === 0) {
      delete exam.answers[exam.currentIndex];
    } else {
      exam.answers[exam.currentIndex] = current;
    }
  } else {
    exam.answers[exam.currentIndex] = oIdx;
  }
  rComp();
}

function saveNumericalAnswer(val) {
  const exam = compState.activeExam;
  if (!exam) return;
  if (val.trim() === '') {
    delete exam.answers[exam.currentIndex];
  } else {
    exam.answers[exam.currentIndex] = val.trim();
  }
}

function clearActiveExamAnswer() {
  const exam = compState.activeExam;
  if (!exam) return;
  delete exam.answers[exam.currentIndex];
  exam.status[exam.currentIndex] = 'unanswered';
  const numInput = document.getElementById('numerical-ans-input');
  if (numInput) numInput.value = '';
  rComp();
}

function setCompTab(tab) {
  compState.currentTab = tab;
  rComp();
}

function updateTargetVal(val) {
  compState.targetScore = parseInt(val);
  const display = document.getElementById('targetScoreDisplay');
  if (display) display.textContent = val;
  saveCompState();
}

function updateDailyTime(val) {
  compState.dailyTime = parseInt(val);
  saveCompState();
  rComp();
}

// Global exports
window.rComp = rComp;
window.setCompTab = setCompTab;
window.updateTargetVal = updateTargetVal;
window.updateDailyTime = updateDailyTime;
window.selectObExam = selectObExam;
window.filterExams = filterExams;
window.navigateObStep = navigateObStep;
window.completeCompOnboarding = completeCompOnboarding;
window.reconfigureCompPlan = reconfigureCompPlan;
window.startCompPractice = startCompPractice;
window.startMockExamSetup = startMockExamSetup;
window.cancelMockExamSetup = cancelMockExamSetup;
window.beginMockExamAfterInstructions = beginMockExamAfterInstructions;
window.switchMockSection = switchMockSection;
window.markMockForReview = markMockForReview;
window.saveAndNextMock = saveAndNextMock;
window.confirmSubmitMockExam = confirmSubmitMockExam;
window.selectMockOption = selectMockOption;
window.saveNumericalAnswer = saveNumericalAnswer;
window.clearActiveExamAnswer = clearActiveExamAnswer;
window.navigateExam = navigateExam;
window.submitMockExam = submitMockExam;
window.closePracticeOverlay = closePracticeOverlay;
window.checkPracticeAnswer = checkPracticeAnswer;
window.checkPracticeNumericalAnswer = checkPracticeNumericalAnswer;
